package com.school.controller;

import com.school.data.StudentDAO;
import java.util.List;

public class GradeController {
    private StudentDAO studentDAO = new StudentDAO();

    public List<String> viewStudentGrades(String studentID) {
        // Validation logic can go here (e.g., checking if ID is empty)
        if (studentID == null || studentID.isEmpty()) {
            return null;
        }
        return null;
    }
}