package com.school.controller;

import com.school.data.StudentDAO;
import java.util.List;

public class SchoolController {
    private StudentDAO dataLayer = new StudentDAO();

    // Use Case 1: View Grades
    public String processGradeRequest(String id) {
        if (id.isEmpty()) return "Please enter an ID.";
        List<String> grades = dataLayer.getGrades(id);
        return String.join("\n", grades);
    }
    public String getStudentInfo(String id) {
        return dataLayer.getStudentDetails(id);
    }
    // Use Case 2: View Attendance (Student)
    public String processAttendanceViewRequest(String id) {
        if (id.isEmpty()) return "Please enter an ID.";
        List<String> attendance = dataLayer.getAttendance(id);
        return String.join("\n", attendance);
    }
    public String login(String username, String password) {
        if (dataLayer.verifyLogin(username, password)) {
            if (username.equals("admin")) return "TEACHER";
            return "STUDENT";
        }
        return "INVALID";
    }
    // Use Case 3: Record Attendance (Teacher) - THIS WAS MISSING
    public String processAttendanceRecord(String id, String status) {
        if (id.isEmpty()) return "Please enter a Student ID first.";

        // Get current date
        String date = java.time.LocalDate.now().toString();

        // Call DAO to save to database
        dataLayer.saveAttendance(id, date, status);

        return "Success: Recorded " + status + " for " + id + " on " + date;
    }
}