package com.school.data;

import java.util.ArrayList;
import java.util.List;

public class AttendanceDAO {
    public List<String> getAttendanceFromDB(String studentID) {
        List<String> records = new ArrayList<>();

        // Mock Data
        if (studentID.equals("23-101296")) {
            records.add("2025-12-01: Present");
            records.add("2025-12-05: Present");
            records.add("2025-12-10: Absent");
        } else {
            records.add("No attendance records for this ID.");
        }
        return records;
    }
}