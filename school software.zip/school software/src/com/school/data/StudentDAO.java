package com.school.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentDAO {
    // Add this inside the StudentDAO class
    private static Map<String, String> userPasswords = new HashMap<>();

    static {
        // Teacher Login
        userPasswords.put("admin", "teacher123");

        // Student Logins (ID is username, password is "pass" + ID)
        userPasswords.put("23-101296", "student123");
        userPasswords.put("23-101077", "student123");
        userPasswords.put("23-101091", "student123");
        userPasswords.put("23-101192", "student123");
    }

    public boolean verifyLogin(String username, String password) {
        return userPasswords.containsKey(username) && userPasswords.get(username).equals(password);
    }
    // These Maps hold the initial full data for your team members
    private static Map<String, String> mockGrades = new HashMap<>();
    private static Map<String, String> mockAttendance = new HashMap<>();

    static {
        // Data for Marwan Khaled
        mockGrades.put("23-101296", "Software Engineering: A\nDatabase Systems: B+\nMathematics: A-");
        mockAttendance.put("23-101296", "2025-12-01: Present, 2025-12-05: Present, 2025-12-10: Present");

        // Data for Youssef Idrees
        mockGrades.put("23-101077", "Software Engineering: B+\nData Structures: A\nMath: B");
        mockAttendance.put("23-101077", "2025-12-01: Present, 2025-12-05: Absent, 2025-12-10: Present");

        // Data for Hany Yasser
        mockGrades.put("23-101107", "Software Engineering: A-\nAlgorithm And Design: B+\nPhysics: A");
        mockAttendance.put("23-101107", "2025-12-01: Present, 2025-12-05: Present, 2025-12-10: Absent");

        // Data for Omar Elsayed
        mockGrades.put("23-101091", "Software Engineering: B\nDataBase: A-\nTechnical Writing: A");
        mockAttendance.put("23-101091", "2025-12-01: Absent, 2025-12-05: Present, 2025-12-10: Present");

        // Data for Yassin Sameh
        mockGrades.put("23-101192", "Software Engineering: A\nData Analysis: B\nCritical Thinking: A-");
        mockAttendance.put("23-101192", "2025-12-01: Present, 2025-12-05: Present, 2025-12-10: Present");
    }
    // Inside StudentDAO.java, update the static block:

    private static Map<String, String> studentProfiles = new HashMap<>();

    static {
        // Marwan Khaled
        studentProfiles.put("23-101296", "Name: Marwan Khaled\nMajor:  Computer Science\nLevel: 3\nGPA: 3.8");

        // Youssef Idrees
        studentProfiles.put("23-101077", "Name: Youssef Idrees\nMajor: Computer Science\nLevel: 3\nGPA: 3.7");

        // Hany Yasser
        studentProfiles.put("23-101107", "Name: Hany Yasser\nMajor:  Computer Science\nLevel: 3\nGPA: 3.9");

        // Omar Elsayed
        studentProfiles.put("23-101091", "Omar Elsayed\nMajor:  Computer Science\nLevel: 3\nGPA: 3.6");

        //Yassin Sameh
        studentProfiles.put("23-101192", "Name: Hany Yasser\nMajor:  Computer Science\nLevel: 3\nGPA: 3.8");


    }

    // Add this method to retrieve the profile
    public String getStudentDetails(String id) {
        return studentProfiles.getOrDefault(id, "Details not found.");
    }
    // Function 1: View Grades (Returns a List as expected by your Controller)
    public List<String> getGrades(String id) {
        List<String> gradesList = new ArrayList<>();
        String data = mockGrades.get(id);
        if (data != null) {
            gradesList.add(data);
        } else {
            gradesList.add("No grades found for ID: " + id);
        }
        return gradesList;
    }

    // Function 2: View Attendance (Returns a List as expected by your Controller)
    public List<String> getAttendance(String id) {
        List<String> attendanceList = new ArrayList<>();
        String data = mockAttendance.get(id);
        if (data != null) {
            attendanceList.add(data);
        } else {
            attendanceList.add("No attendance records found for ID: " + id);
        }
        return attendanceList;
    }

    // Function 3: Record Attendance (Saves new data into the Map)
    public void saveAttendance(String id, String date, String status) {
        String newEntry = date + ": " + status;

        // If student already has records, add to them. If not, create new.
        if (mockAttendance.containsKey(id)) {
            String updatedRecords = mockAttendance.get(id) + "\n" + newEntry;
            mockAttendance.put(id, updatedRecords);
        } else {
            mockAttendance.put(id, newEntry);
        }

        System.out.println("Saved to DB: ID " + id + " marked " + status + " on " + date);
    }
}