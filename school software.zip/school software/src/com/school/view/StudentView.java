package com.school.view;
import com.school.controller.GradeController;

import java.util.Scanner;
import java.util.List;
public class StudentView {
    private GradeController controller = new GradeController();

    public void showGradeScreen() {
        Scanner input = new Scanner(System.in);

        System.out.println("=== SCHOOL MANAGEMENT SYSTEM: VIEW GRADES ===");
        System.out.print("Enter your Student ID: ");
        String id = input.nextLine();

        // 1. Send request to Controller
        List<String> results = controller.viewStudentGrades(id);

        // 2. Display the data received from the controller
        System.out.println("\n--- YOUR ACADEMIC RECORD ---");
        if (results != null) {
            for (String record : results) {
                System.out.println(record);
            }
        } else {
            System.out.println("Invalid ID entered.");
        }
        System.out.println("----------------------------");
    }

    public static void main(String[] args) {
        StudentView ui = new StudentView();
        ui.showGradeScreen();
    }
}
