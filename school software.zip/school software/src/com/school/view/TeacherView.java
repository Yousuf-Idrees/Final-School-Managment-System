package com.school.view;
import com.school.controller.AttendanceController;
import java.util.Scanner;

public class TeacherView {
    private AttendanceController controller = new AttendanceController();

    public void showAttendanceScreen() {
        Scanner input = new Scanner(System.in);

        System.out.println("\n=== SCHOOL MANAGEMENT SYSTEM: RECORD ATTENDANCE ===");

        System.out.print("Enter Date (YYYY-MM-DD): ");
        String date = input.nextLine();

        System.out.print("Enter Student ID: ");
        String id = input.nextLine();

        System.out.print("Enter Status (P for Present / A for Absent): ");
        String status = input.nextLine();

        // Send data to Controller
        String message = controller.processAttendance(date, id, status);

        // Display result
        System.out.println("System Notification: " + message);
    }
}