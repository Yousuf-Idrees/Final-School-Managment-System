package com.school.view;

import com.school.controller.SchoolController;
import javax.swing.*;
import java.awt.*;

public class SchoolSystemGUI extends JFrame {
    private SchoolController controller = new SchoolController();
    private CardLayout cardLayout = new CardLayout();
    private JPanel mainContentPanel = new JPanel(cardLayout);

    // Design Colors
    Color bgColor = new Color(158, 179, 194);
    Color btnColor = new Color(47, 85, 101);
    Color headerBoxColor = new Color(232, 222, 222);

    public SchoolSystemGUI(boolean isTeacher, String loggedInID) {
        setTitle("School Management System");
        setSize(950, 850); // Slightly wider for better layout
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(bgColor);
        setLayout(new BorderLayout());

        mainContentPanel.add(createAttendancePage(isTeacher, loggedInID), "Attendance");
        mainContentPanel.add(createGradesPage(isTeacher, loggedInID), "Grades");

        JPanel navBar = new JPanel(new GridLayout(1, 5));
        navBar.setPreferredSize(new Dimension(800, 60));
        String[] tabs = {"Login", "Attendance Record", "Student Grade", "Announcements", "Manage"};

        for (String tab : tabs) {
            JButton btn = new JButton(tab);
            navBar.add(btn);
            if (tab.equals("Login")) btn.addActionListener(e -> { new LoginGUI(); this.dispose(); });
            if (tab.equals("Attendance Record")) btn.addActionListener(e -> cardLayout.show(mainContentPanel, "Attendance"));
            if (tab.equals("Student Grade")) btn.addActionListener(e -> cardLayout.show(mainContentPanel, "Grades"));
        }

        add(mainContentPanel, BorderLayout.CENTER);
        add(navBar, BorderLayout.SOUTH);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JPanel createAttendancePage(boolean isTeacher, String id) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bgColor);

        JLabel title = new JLabel("Attendance Management", SwingConstants.CENTER);
        title.setOpaque(true);
        title.setBackground(headerBoxColor);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setPreferredSize(new Dimension(800, 60));
        panel.add(title, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(bgColor);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        // --- BIGGER SEARCH SECTION ---
        JPanel searchSection = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        searchSection.setOpaque(false);

        JTextField idField = new JTextField(id, 15); // Increased column size
        idField.setFont(new Font("Arial", Font.PLAIN, 16));

        JButton viewBtn = new JButton("View History");
        viewBtn.setPreferredSize(new Dimension(140, 35));

        searchSection.add(new JLabel("Search ID: "));
        searchSection.add(idField);
        searchSection.add(viewBtn);

        // Teacher Recording Tools (Only for Teacher)
        if (isTeacher) {
            JComboBox<String> statusBox = new JComboBox<>(new String[]{"Present", "Absent"});
            JButton recordBtn = new JButton("Record");
            searchSection.add(new JLabel(" | Status: "));
            searchSection.add(statusBox);
            searchSection.add(recordBtn);

            recordBtn.addActionListener(e -> {
                String msg = controller.processAttendanceRecord(idField.getText(), (String)statusBox.getSelectedItem());
                JOptionPane.showMessageDialog(this, msg);
            });
        }

        centerPanel.add(searchSection);

        // Display Area
        JEditorPane displayArea = new JEditorPane();
        displayArea.setContentType("text/html");
        displayArea.setEditable(false);
        centerPanel.add(new JScrollPane(displayArea));

        viewBtn.addActionListener(e -> {
            String details = controller.getStudentInfo(idField.getText()); // Retrieve Name/Year
            String history = controller.processAttendanceViewRequest(idField.getText());
            displayArea.setText(formatHTMLResponse(details, history, "Attendance"));
        });

        if (!isTeacher) {
            idField.setEditable(false);
            displayArea.setText(formatHTMLResponse(controller.getStudentInfo(id), controller.processAttendanceViewRequest(id), "Attendance"));
        }

        panel.add(centerPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createGradesPage(boolean isTeacher, String id) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(bgColor);

        JLabel title = new JLabel("Student Grades", SwingConstants.CENTER);
        title.setOpaque(true);
        title.setBackground(headerBoxColor);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setPreferredSize(new Dimension(800, 60));
        panel.add(title, BorderLayout.NORTH);

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(bgColor);
        content.setBorder(BorderFactory.createEmptyBorder(20, 80, 20, 80));

        // --- BIGGER SEARCH BAR ---
        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.setOpaque(false);
        JTextField searchField = new JTextField(id, 20);
        searchField.setFont(new Font("Arial", Font.PLAIN, 16));
        JButton searchBtn = new JButton("Search Records");
        searchBtn.setPreferredSize(new Dimension(150, 35));

        if (isTeacher) {
            topPanel.add(new JLabel("Enter Student ID: "));
            topPanel.add(searchField);
            topPanel.add(searchBtn);
        }
        content.add(topPanel, BorderLayout.NORTH);

        JEditorPane gradeDisplay = new JEditorPane();
        gradeDisplay.setContentType("text/html");
        gradeDisplay.setEditable(false);
        content.add(new JScrollPane(gradeDisplay), BorderLayout.CENTER);

        searchBtn.addActionListener(e -> {
            String details = controller.getStudentInfo(searchField.getText());
            String data = controller.processGradeRequest(searchField.getText());
            gradeDisplay.setText(formatHTMLResponse(details, data, "Grades"));
        });

        if (!isTeacher) {
            gradeDisplay.setText(formatHTMLResponse(controller.getStudentInfo(id), controller.processGradeRequest(id), "Grades"));
        }

        panel.add(content, BorderLayout.CENTER);
        return panel;
    }

    // --- HTML FORMATTING FOR NAME, YEAR, AND DATA ---
    private String formatHTMLResponse(String studentInfo, String data, String type) {
        // studentInfo looks like: "Name: Marwan Khaled\nMajor: IT\nYear: 2025"
        String[] info = studentInfo.split("\n");
        String name = info.length > 0 ? info[0] : "Unknown Student";
        String year = info.length > 2 ? info[2] : "Academic Year: 2025";

        StringBuilder html = new StringBuilder("<html><body style='font-family: Arial; padding: 25px;'>");

        // Student Info Header (Real Look)
        html.append("<div style='background-color: #f0f0f0; padding: 10px; border-left: 5px solid #2F5565;'>")
                .append("<h1 style='margin: 0; color: #2F5565;'>").append(name.replace("Name: ", "")).append("</h1>")
                .append("<p style='margin: 5px 0; font-size: 14pt; color: #555;'>").append(year).append("</p>")
                .append("</div><br><hr><br>");

        if (type.equals("Grades")) {
            String[] lines = data.split("\n");
            for (String line : lines) {
                if (line.contains(":")) {
                    String[] parts = line.split(":");
                    html.append("<div style='border-bottom: 1px solid #ccc; margin-bottom: 15px; padding-bottom: 5px;'>")
                            .append("<span style='font-size: 18pt; font-weight: bold;'>").append(parts[0]).append("</span>")
                            .append("<span style='float: right; font-size: 18pt; color: #2F5565;'>").append(parts[1]).append("</span>")
                            .append("</div>");
                }
            }
        } else {
            html.append("<p style='font-size: 15pt; line-height: 1.6;'>").append(data.replace("\n", "<br>")).append("</p>");
        }

        html.append("</body></html>");
        return html.toString();
    }
}